package Ruben.Tema3.Redondear;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		float numero1 = sc.nextFloat();
		float numero2 = sc.nextFloat();
		
		Operacion operacion1 = new Operacion(numero1, numero2);
		
		suma.operacion1;

	}

}
