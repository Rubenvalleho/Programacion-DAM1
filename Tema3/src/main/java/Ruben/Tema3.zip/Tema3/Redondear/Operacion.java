package Ruben.Tema3.Redondear;

public class Operacion {
	private float numero1;
	private float numero2;
	

	public Operacion (float numero1, float numero2) {
		this.numero1 = numero1;
		this.numero2 = numero2;
	}
	
	public  () {
		
	}
	
}
