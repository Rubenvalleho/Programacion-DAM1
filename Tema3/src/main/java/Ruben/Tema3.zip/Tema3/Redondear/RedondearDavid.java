package David_Lozano_dam.Tema3.Ej2_redondear;

//2. Realiza un método redondear() al que se le pasa como parámetro un numero float y los decimales que deben quedar después de redondear, 
//y retorna el numero redondeado. Ejemplo: redondear( 234.492,343 ) Da como resultado : 234.492 
public class Redondear {
	
	//Atributo
	private float numero;
	
	//Constructor
	public Redondear(float numero) {
		this.numero=numero;
	}
	
	//toString
	@Override
	public String toString() {
	return "El numero es: " + numero;	
	}
	
	//Metodo get
	public float getNumero() {
		return numero;
	}
	
	//Metodo set
	public void setNumero(float numero) {
		this.numero=numero;
	}
	
	//Metodo redondear
	public void metodoRedondear(float numero) {
		if (((getNumero()-(int)getNumero())*10)>4) {
			System.out.println((int)getNumero()+1);
		}
		else {
			System.out.println((int)getNumero());
		}
	}
}