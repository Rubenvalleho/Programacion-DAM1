package David_Lozano_dam.Tema3.Ej2_redondear;

import java.util.Scanner;

public class Ejercicio2 {
	public static void main(String[] args) {
		System.out.println("Dame un numero");
		Scanner sc = new Scanner(System.in);
		float numero= sc.nextFloat();
		Redondear redondeo = new Redondear(numero);
		sc.close();
		
		System.out.println("El numero escrito es: " + numero);
		redondeo.metodoRedondear(numero);
	}

}
