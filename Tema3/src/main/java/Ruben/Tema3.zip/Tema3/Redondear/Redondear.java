package Ruben.Tema3.Redondear;

public class Redondear {
	private float numero;
	
	public Redondear (float numero) {
		this.numero=numero;
	}
	
}
