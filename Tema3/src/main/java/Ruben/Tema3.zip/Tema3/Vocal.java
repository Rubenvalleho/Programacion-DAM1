package Ruben.Tema3;

public class Vocal {
	
	public boolean esVocal (char vocal) {
		if (vocal=='a' || vocal=='e' || vocal=='i' || vocal=='o' || vocal=='u') {
			return true;
		}
		else {
			return false;
		}
	}
}
