package Ruben.Tema3;

public class Prueba1 {

	public static void main(String[] args) {
		public class Coche {
			private String matricula;
			private String color;
		}
		Coche coche1 = new Coche();
		
		coche1.matricula=;
		public Coche () {
			
			/*this.nombre = nombre;
			this.edad = edad;
			this.altura = altura;*/
			}
}
